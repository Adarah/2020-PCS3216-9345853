# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src', 'src.data', 'tests']

package_data = \
{'': ['*']}

install_requires = \
['attr>=0.3.1,<0.4.0',
 'attrs>=19.3.0,<20.0.0',
 'hypothesis-pytest>=0.19.0,<0.20.0',
 'loguru>=0.4.1,<0.5.0',
 'numpy>=1.18.3,<2.0.0',
 'pyparsing>=2.4.7,<3.0.0',
 'pytest-mock>=3.1.0,<4.0.0',
 'pytest>=5.4.2,<6.0.0']

setup_kwargs = {
    'name': '2020-pcs3216-9345853',
    'version': '0.1.0',
    'description': 'Projeto de SisProg',
    'long_description': None,
    'author': 'Adarah',
    'author_email': 'lucasyharada@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
